<?php /* Smarty version 2.6.18, created on 2008-07-03 19:39:52
         compiled from main/home/index.tpl */ ?>
<b>Your Groups</b><br/>
<?php unset($this->_sections['a']);
$this->_sections['a']['name'] = 'a';
$this->_sections['a']['loop'] = is_array($_loop=$this->_tpl_vars['groups']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['a']['show'] = true;
$this->_sections['a']['max'] = $this->_sections['a']['loop'];
$this->_sections['a']['step'] = 1;
$this->_sections['a']['start'] = $this->_sections['a']['step'] > 0 ? 0 : $this->_sections['a']['loop']-1;
if ($this->_sections['a']['show']) {
    $this->_sections['a']['total'] = $this->_sections['a']['loop'];
    if ($this->_sections['a']['total'] == 0)
        $this->_sections['a']['show'] = false;
} else
    $this->_sections['a']['total'] = 0;
if ($this->_sections['a']['show']):

            for ($this->_sections['a']['index'] = $this->_sections['a']['start'], $this->_sections['a']['iteration'] = 1;
                 $this->_sections['a']['iteration'] <= $this->_sections['a']['total'];
                 $this->_sections['a']['index'] += $this->_sections['a']['step'], $this->_sections['a']['iteration']++):
$this->_sections['a']['rownum'] = $this->_sections['a']['iteration'];
$this->_sections['a']['index_prev'] = $this->_sections['a']['index'] - $this->_sections['a']['step'];
$this->_sections['a']['index_next'] = $this->_sections['a']['index'] + $this->_sections['a']['step'];
$this->_sections['a']['first']      = ($this->_sections['a']['iteration'] == 1);
$this->_sections['a']['last']       = ($this->_sections['a']['iteration'] == $this->_sections['a']['total']);
?>
<a href="<?php echo $this->_tpl_vars['root']; ?>
group/<?php echo $this->_tpl_vars['groups'][$this->_sections['a']['index']]['id']; ?>
"><?php echo $this->_tpl_vars['groups'][$this->_sections['a']['index']]['name']; ?>
</a><br/>
<?php endfor; else: ?>
<i>No groups!</i>
<?php endif; ?>
<br/>
<a href="<?php echo $this->_tpl_vars['root']; ?>
group/add">New Group</a>
<br/><br/>
<a href="<?php echo $this->_tpl_vars['root']; ?>
logout">Log out</a>