<?php /* Smarty version 2.6.18, created on 2008-07-03 13:31:49
         compiled from 404/index.tpl */ ?>
<p><b>404 Page not found</b></p>

<p>You have entered or clicked on an invalid link.</p>