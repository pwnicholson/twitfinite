<?php /* Smarty version 2.6.18, created on 2008-07-03 13:31:49
         compiled from index.tpl */ ?>
<html>
<head>
<title><?php echo $this->_tpl_vars['site_name']; ?>
 | <?php echo $this->_tpl_vars['title']; ?>
</title>
<script type="text/javascript" src="<?php echo $this->_tpl_vars['root']; ?>
_js/prototype.js"></script>
<script type="text/javascript" src="<?php echo $this->_tpl_vars['root']; ?>
_js/functions.js"></script>
<link href="<?php echo $this->_tpl_vars['root']; ?>
_css/stylesheet.css" rel="stylesheet" type="text/css" />
<link href="<?php echo $this->_tpl_vars['root']; ?>
_css/spiffy.css" rel="stylesheet" type="text/css" />
<link href="<?php echo $this->_tpl_vars['root']; ?>
_css/navlist.css" rel="stylesheet" type="text/css" />
<link href="<?php echo $this->_tpl_vars['root']; ?>
_css/form.css" rel="stylesheet" type="text/css" />
</head>

<script language="javascript">
root = "<?php echo $this->_tpl_vars['root']; ?>
";
<?php echo '
// Detect if we\'re in a frame or not.
// We really should be if we\'re not.
//var loc = ""+top.location+"";
//if(!loc.match("frame.php")) {
//	window.location = root+\'frame.php\';
//}
'; ?>

</script>
<body<?php if ($this->_tpl_vars['onload']): ?> onload="<?php echo $this->_tpl_vars['onload']; ?>
"<?php endif; ?>>

<?php if ($this->_tpl_vars['err']): ?>
<p>
<?php unset($this->_sections['a']);
$this->_sections['a']['name'] = 'a';
$this->_sections['a']['loop'] = is_array($_loop=$this->_tpl_vars['err']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['a']['show'] = true;
$this->_sections['a']['max'] = $this->_sections['a']['loop'];
$this->_sections['a']['step'] = 1;
$this->_sections['a']['start'] = $this->_sections['a']['step'] > 0 ? 0 : $this->_sections['a']['loop']-1;
if ($this->_sections['a']['show']) {
    $this->_sections['a']['total'] = $this->_sections['a']['loop'];
    if ($this->_sections['a']['total'] == 0)
        $this->_sections['a']['show'] = false;
} else
    $this->_sections['a']['total'] = 0;
if ($this->_sections['a']['show']):

            for ($this->_sections['a']['index'] = $this->_sections['a']['start'], $this->_sections['a']['iteration'] = 1;
                 $this->_sections['a']['iteration'] <= $this->_sections['a']['total'];
                 $this->_sections['a']['index'] += $this->_sections['a']['step'], $this->_sections['a']['iteration']++):
$this->_sections['a']['rownum'] = $this->_sections['a']['iteration'];
$this->_sections['a']['index_prev'] = $this->_sections['a']['index'] - $this->_sections['a']['step'];
$this->_sections['a']['index_next'] = $this->_sections['a']['index'] + $this->_sections['a']['step'];
$this->_sections['a']['first']      = ($this->_sections['a']['iteration'] == 1);
$this->_sections['a']['last']       = ($this->_sections['a']['iteration'] == $this->_sections['a']['total']);
?>
	<div class="err"><?php echo $this->_tpl_vars['err'][$this->_sections['a']['index']]; ?>
</div>
<?php endfor; endif; ?>
<?php endif; ?>
<?php if ($this->_tpl_vars['msg']): ?>
<?php unset($this->_sections['a']);
$this->_sections['a']['name'] = 'a';
$this->_sections['a']['loop'] = is_array($_loop=$this->_tpl_vars['msg']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['a']['show'] = true;
$this->_sections['a']['max'] = $this->_sections['a']['loop'];
$this->_sections['a']['step'] = 1;
$this->_sections['a']['start'] = $this->_sections['a']['step'] > 0 ? 0 : $this->_sections['a']['loop']-1;
if ($this->_sections['a']['show']) {
    $this->_sections['a']['total'] = $this->_sections['a']['loop'];
    if ($this->_sections['a']['total'] == 0)
        $this->_sections['a']['show'] = false;
} else
    $this->_sections['a']['total'] = 0;
if ($this->_sections['a']['show']):

            for ($this->_sections['a']['index'] = $this->_sections['a']['start'], $this->_sections['a']['iteration'] = 1;
                 $this->_sections['a']['iteration'] <= $this->_sections['a']['total'];
                 $this->_sections['a']['index'] += $this->_sections['a']['step'], $this->_sections['a']['iteration']++):
$this->_sections['a']['rownum'] = $this->_sections['a']['iteration'];
$this->_sections['a']['index_prev'] = $this->_sections['a']['index'] - $this->_sections['a']['step'];
$this->_sections['a']['index_next'] = $this->_sections['a']['index'] + $this->_sections['a']['step'];
$this->_sections['a']['first']      = ($this->_sections['a']['iteration'] == 1);
$this->_sections['a']['last']       = ($this->_sections['a']['iteration'] == $this->_sections['a']['total']);
?>
	<div class="msg"><?php echo $this->_tpl_vars['msg'][$this->_sections['a']['index']]; ?>
</div>
<?php endfor; endif; ?>
</p>
<?php endif; ?>

<?php if ($this->_tpl_vars['include']): ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => ($this->_tpl_vars['include']).".tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<?php endif; ?>


<div id="url" style="display: <?php if ($this->_tpl_vars['dev']): ?>block<?php else: ?>none<?php endif; ?>">
Browser URL:
<script language="javascript">
document.write(location.href);
</script>
<br/>
Code URL: <?php echo $this->_tpl_vars['fullurl']; ?>

</div>

</body>
</html>