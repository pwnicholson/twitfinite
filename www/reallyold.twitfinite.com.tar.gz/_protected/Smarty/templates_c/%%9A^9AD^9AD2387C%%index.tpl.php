<?php /* Smarty version 2.6.18, created on 2008-07-03 15:37:18
         compiled from main/login/index.tpl */ ?>
<form method="post">
Username: <input type="text" id="username" name="username" size="16" /><br/>
Password: <input type="password" id="password" name="password" size="16" /><br/>
<input type="submit" value="Login" />
</form>