<?
/*
	 Copyright 2007 Garrett Bartley.

    This file is part of Munkee's Framework.

    Munkee's Framework is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Munkee's Framework is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Munkee's Framework.  If not, see <http://www.gnu.org/licenses/>.
*/

/* Page protection in case the .htaccess file is hosed */
if(eregi('functions.php',$_SERVER['PHP_SELF'])) exit('hack attempt . . . denied');


/* Connect to a database with a DSN (array or string) */
function db_connect($dsn) {
	$options = array('debug' => 2, 'result_buffering' => true);
	if(is_array($dsn)) $dsn = build_dsn($dsn);
	$conn =& MDB2::factory($dsn, $options);
	if (PEAR::isError($conn)) {
		echo $conn->getMessage();
	}
	$conn->setFetchMode(MDB2_FETCHMODE_ASSOC);
	/* This query is run to check and make sure the connection is successfull */
	$query = "SELECT 1+1";
	q($query,$conn);

	return $conn;
}

/* Perform a SQL query */
function q($sql,$conn) {
	$dev = FALSE;

	$res =& $conn->query($sql);
	if(PEAR::isError($res)) {
		if($dev) {
			echo $res->getMessage().'<br />';
			echo '<pre>';
			print_r($conn->dsn);
			echo '</pre>';
		}
		return FALSE;
	} else {
		return $res;
	}
}

/* For dev environments, this can be very handy */
function ip_trans($ip) {
	/* switch($ip) {
		case '192.168.10.16':
			$ip = '64.203.96.115';
			break;
		case '192.168.10.52':
			$ip = '64.203.96.116';
			break;
		case '192.168.200.237':
			$ip = '64.203.98.27';
			break;
	} */

	return $ip;
}

/* Build the DSN string from an array */
function build_dsn($arr) {
	global $dev;
	if($dev) $arr['db_host'] = ip_trans($arr['db_host']);

	if(count($arr)==5) {
		$dsn = $arr['db_type'].'://'.$arr['db_user'].':'.$arr['db_pass'].'@'.$arr['db_host'].'/'.$arr['db_name'];
	} else {
		$dsn = FALSE;
	}

	return $dsn;
}

/* A weird way to do an if with an array */
function array_if($arr,$op,$val) {
	$ret = TRUE;
	for($a=0;$a<count($arr);$a++) {
		$if = 'if( '.$arr[$a].' '.$op.' '.$val.' ) { return TRUE; } else { return FALSE; }';
		$if = eval($if);
		if(!$if && $ret) $ret = FALSE;
	}

	return $ret;
}

/* Make Spiffy Corners! */
function spiffy_start() {
	$ret = '<div>'
		.'<b class="spiffy">'
		.'<b class="spiffy1"><b></b></b>'
		.'<b class="spiffy2"><b></b></b>'
		.'<b class="spiffy3"></b>'
		.'<b class="spiffy4"></b>'
		.'<b class="spiffy5"></b>'
		.'</b> <div class="spiffy_content">';

	return $ret;
}

function spiffy_stop() {
	$ret = '</div>'
		.'<b class="spiffy">'
		.'<b class="spiffy5"></b>'
		.'<b class="spiffy4"></b>'
		.'<b class="spiffy3"></b>'
		.'<b class="spiffy2"><b></b></b>'
		.'<b class="spiffy1"><b></b></b>'
		.'</b>'
		.'</div>';

	return $ret;
}

function spiffy($str) {
	return spiffy_start().$str.spiffy_stop();
}

/* Build an INSERT query from an array */
function build_insert($table,$arr) {
	$keys = array_keys($arr);
	for($a=0;$a<count($keys);$a++) {
		$values[] = str_replace("'","''",$arr[$keys[$a]]);
	}

	$str = "INSERT INTO [".$table."] ([".implode('],[',$keys)."]) VALUES ('".implode("','",$values)."')";

	return $str;
}

/* Build an UPDATE query from an array */
/* The $where is a string (e.g. "id=123") */
function build_update($table,$arr,$where) {
	$str = "UPDATE [".$table."] SET ";
	$keys = array_keys($arr);
	for($a=0;$a<count($keys);$a++) {
		$updates[] = "[".$keys[$a]."]='".str_replace("'","''",$arr[$keys[$a]])."'";
	}

	$str .= implode(',',$updates).' WHERE '.$where;

	return $str;
}

/* Do a redirect within the site */
function redirect($url='') {
	echo $url;
	#if(strlen(trim($url))>0) header('location: '.$root.$url);
}

/* This simply removes all non-alpha, non-number characters */
function scrub($str) {
	$str = preg_replace('/[^A-Za-z0-9]/','',$str);
	return $str;
}

function scrubwithspaces($str) {
	$str = preg_replace('/[^A-Za-z0-9 ]/','',$str);
	return $str;
}

function scrubdbdefaults($str) {
	$str = substr($str,2,strlen($str)-4);
	return $str;
}

function wlog($str='') {
	echo '<script language="javascript">';
	echo "document.write('[".date('Y-m-d H:i:s')."]"." ".$str."<br/>');\n";
	echo '</script>';
	scrolldown();
	ob_flush();
	flush();
}

function wlog_step($str='') {
	echo '<script language="javascript">';
	echo "progress_wrapper = parent.document.getElementById('progress_wrapper');\n";
	echo "if(progress_wrapper.style.display!='none') progress_wrapper.style.display='none';\n";
	echo "parent.document.getElementById('step').innerHTML = '".$str."';\n";
	echo "document.write('[".date('Y-m-d H:i:s')."]"." ".$str."<br/>');\n";
	echo '</script>';
	if(ob_get_length()>0) {
		ob_flush();
		flush();
	}
}

function wlog_progress($pct=0) {
	echo '<script language="javascript">';
	echo "progress = parent.document.getElementById('progress');\n";
	echo "progress_wrapper = parent.document.getElementById('progress_wrapper');\n";
	echo "progress_pct = parent.document.getElementById('progress_pct');\n";
	echo "if(progress_wrapper.style.display=='none') progress_wrapper.style.display='';\n";
	echo "progress.style.width = \"".$pct."%\";\n";
	echo "progress_pct.innerHTML = \"".$pct."%\";\n";
	echo '</script>';
	if(ob_get_length()>0) {
		ob_flush();
		flush();
	}
}

function wlog_step_graphic() {
	global $root;

	echo '<script language="javascript">';
	echo "parent.document.getElementById('step').innerHTML = parent.document.getElementById('step').innerHTML+' <img src=\"".$root."/images/kit-loader.gif\" style=\"position: relative; top:4px;\" />';\n";
	echo '</script>';
	if(ob_get_length()>0) {
		ob_flush();
		flush();
	}
}

function scrolldown() {
	echo '<script language="javascript">';
	echo 'document.body.scrollTop = document.body.scrollHeight';
	echo '</script>';
	if(ob_get_length()>0) {
		ob_flush();
		flush();
	}
}

function wlog_keep_going($keep_going_link) {
	global $root;

	echo "<script language='javascript'>";
	echo "keep_going = parent.document.getElementById('keep_going');";
	echo "parent.document.getElementById('keep_going_label').style.display = 'none';";
	echo "if(keep_going.checked==true) {";
	echo "str = 'Continuing to processing avpops in 5 seconds';";
	echo "progress_wrapper = parent.document.getElementById('progress_wrapper');\n";
	echo "step = parent.document.getElementById('step');";
	echo "if(progress_wrapper.style.display!='none') progress_wrapper.style.display='none';\n";
	echo "step.innerHTML = str;\n";
	echo "document.write('[".date('Y-m-d H:i:s')."] '+str+'<br/>');\n";
	echo "step.innerHTML = step.innerHTML+' <img src=\"".$root."/images/kit-loader.gif\" style=\"position: relative; top:4px;\" />';\n";
	echo "show_log = '';";
	echo "keep_going = '';";
	echo "if(parent.document.getElementById('show_log').checked==true) show_log='/y';";
	echo "window.setTimeout('parent.window.location.href=\"".$keep_going_link."/y'+show_log+'\"',5000)";
	echo "} else {";
	echo "parent.document.getElementById('reset_button').style.display = 'block';";
	echo "}";
	echo "</script>";
	scrolldown();
}
?>
